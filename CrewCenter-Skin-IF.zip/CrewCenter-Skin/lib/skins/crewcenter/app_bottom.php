        </div>
        <!-- /.content-wrapper -->
        
        <footer class="main-footer">
            <div class="pull-right hidden-xs">
                CrewCenter by Mark Swan | Powered by phpVMS
            </div>
            <strong>Copyright &copy; <?php echo date('Y') ?> <?php echo SITE_NAME; ?></strong>
        </footer>
    </div>
    <!-- ./wrapper -->
</div>