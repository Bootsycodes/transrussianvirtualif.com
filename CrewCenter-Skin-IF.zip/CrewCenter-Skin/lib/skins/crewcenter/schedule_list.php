<div id="scheduleresults">
<?php
if($allroutes)
	Template::ShowTemplate('schedule_results.php');
?>
</div>