# FireCrew3

Thank you for downloading FireCrew3.
Hope to have you onboard soon!  

# Installation:
This skin is designed to be used on a phpVMS installation on a subdomain. Your main website will be static webpages without phpVMS. This skin has been tested on PHPVMS version 5.5.2 running PHP version 5.6. No support would be guaranteed for other versions of PHPVMS.

# To install:

* Download the whole repository.
* Create a new folder named FireCrew3.
* Unzip all the files from the archive into the newly created folder.
* Install the AirCharts module from Parkho.
* Upload the FireCrew3 folder to your lib/skins folder.
* Go to your Admin Panel.
* Navigate to Site & Settings -> General Seetings
* In Current Skin dropdown choose FireCrew3.
* Add these lines to your core/local.config.php file

Config::Set('CLOSE_BIDS_AFTER_EXPIRE', true);

Config::Set('BID_EXPIRE_TIME', '48');
* You are good to go!

# Contact
If you have any comments, queries or suggestions, please feel free to email me at hiparthparth@gmail.com

© Parth Parth 2019. hiparthparth@gmail.com
# This project is no longer being actively maintained. Please email me if you enounter any security vulnerabilities.
