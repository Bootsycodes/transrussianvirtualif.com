                <nav class="pull-left" style="width:30%;">
                    <ul>

                        <li>
                            <a href="http://www.myselfparth.gq/">
                                &copy; Parth Parth <script>document.write(new Date().getFullYear())</script>
                            </a>
                        </li>
                    </ul>
                </nav>
                <nav class="pull-right" style="width:25%;">
                    <ul>

                        <li>
                            <a href="http://www.myselfparth.gq/">
                                Skin Made with <i class="fa fa-heart" style="color:red;"></i> by Parth Parth
                            </a>
                        </li>
                    </ul>
                </nav>
