<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<style>
.main-panel {
    width:100%;
    overflow:hidden;
}
.main-panel{
    background-image: url('<?php echo SITE_URL?>/lib/skins/FireCrew3/assets/img/backgroundlogin.jpg');
    background-size: cover;
}
</style>
<body>
	<div class="col-md-4 col-md-offset-4">
		<div class="card text-center" style="padding-top: 5%;padding-bottom: 5%;">
			Your registration is still pending. You will be notified of the status by email.
		</div>
	</div>
    <footer class="footer footer-transparent">
                <div class="container card col-md-4 col-sm-6 col-md-offset-4 col-sm-offset-3">
                    <div class="copyright">
                        &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://www.myselfparth.gq/">Parth Parth</a>
                    </div>
                </div>
    </footer>
</body>