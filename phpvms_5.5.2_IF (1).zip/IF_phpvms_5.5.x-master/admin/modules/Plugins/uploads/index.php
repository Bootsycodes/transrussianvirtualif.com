<?php
echo'No direct directory access allowed';
?>