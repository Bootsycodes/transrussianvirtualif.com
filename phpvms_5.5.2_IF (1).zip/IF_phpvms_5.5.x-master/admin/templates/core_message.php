<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<div id="messagebox">
<?php echo $message;?>
</div>		