<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<div id="sidecolumn"><?php echo $sidebar;?></div>