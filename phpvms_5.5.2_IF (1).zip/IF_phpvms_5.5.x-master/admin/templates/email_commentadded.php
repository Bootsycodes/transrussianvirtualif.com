<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
Dear <?php echo $firstname. ' ' .$lastname?>,

A comment has been added to your flight report.
To view it, visit:
<?php echo SITE_URL;?>/index.php/pireps/view/<?php echo $pirepid;?>

Thanks!
The <?php echo SITE_NAME;?> Team