<hr />
Plugin Manager - Version 1.0 - &copy; <a href="http://www.simpilotgroup.com">Simpilotgroup</a>
<br /><br /><br />