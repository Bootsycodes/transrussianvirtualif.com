<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a id="dialog" class="jqModal" href="<?php echo SITE_URL?>/admin/action.php/operations/addairline">Add Airline</a>
	</span></li>
</ul>
<h3>Help</h3>
<p>These are the airlines served under your airline "group". You can have a multiple airlines, which serve different groups, or were part of an acquisition. Schedules that are specific to each airline can be setup.</p>