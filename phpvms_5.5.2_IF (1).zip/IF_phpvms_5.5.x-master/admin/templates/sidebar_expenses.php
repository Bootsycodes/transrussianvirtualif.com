<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a id="dialog" class="jqModal" 
			href="<?php echo SITE_URL?>/admin/action.php/finance/addexpense">Add an Expense
		</a>
	</span></li>
</ul>
<h3>Help</h3>
<p>These are all of your airlines expenses</p>