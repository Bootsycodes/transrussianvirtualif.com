<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>CSV Import</h3>
<p>From here, you may import a CSV (comma separated values) form to import your schedules.</p>

<p>A template CSV is available <a href="<?php echo SITE_URL ?>/admin/lib/template.csv">here</a></p>