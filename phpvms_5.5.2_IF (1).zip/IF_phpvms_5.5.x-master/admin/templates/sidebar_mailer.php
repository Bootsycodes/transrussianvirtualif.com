<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Help</h3>
<p>From here, you can send an email to all of your pilot's at once</p>
<h3>Variables</h3>
<p>Click to add:</p>
<p><strong><a href="#" class="addtoEditor">{PILOT_FNAME}</strong></a><br />Insert the pilot's first name</p>
<p><strong><a href="#" class="addtoEditor">{PILOT_LNAME}</strong></a><br />Insert the pilot's last name</p>
<p><strong><a href="#" class="addtoEditor">{PILOT_ID}</strong></a><br />Insert the pilot's pilot id (VMA001)</p>