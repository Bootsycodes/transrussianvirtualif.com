<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/sitecms/addpageform">Add Page</a>
	</span></li>
	
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/sitecms/viewpages">View Pages</a>
	</span></li>
</ul>
<h3>Help</h3>
<p>You can create "pages" for your site; if the navigation bar is setup properly in your skin, then these pages will automatically show up, and be able to be linked to. </p>
<p>Right click on the link in the 'File/Link' column, and select "Copy Link" to get the link to that page.</p>