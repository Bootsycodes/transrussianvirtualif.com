<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Help</h3>
<p>These are your pilots whose registrations are pending. Accept or reject the pilot. They will receive an email with your decision. They will not be able to log in, or submit any reports until their registration has been accepted.</p>