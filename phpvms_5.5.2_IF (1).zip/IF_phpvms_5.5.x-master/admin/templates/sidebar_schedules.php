<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Tasks</h3>
<ul class="filetree treeview-famfamfam">
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/operations/addschedule">Add Schedule</a>
	</span></li>
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/operations/activeschedules">View Schedules</a>
	</span></li>
	<li><span class="file">
		<a href="<?php echo SITE_URL?>/admin/index.php/maintenance/resetdistances">Recalculate Distances</a>
	</span></li>	
</ul>
<h3>Help</h3>
<p>These are all the schedules your airlines currently server. When you add a schedule, you can add it on a per-airline basis.</p>
<p>Notes can be used to add schedule frequency, or any other related information.</p>