<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
Dear <?php echo $firstname .' '. $lastname; ?>,

Your account have been made at <?php echo SITE_NAME?>, but your account has not yet been activated. You will receive an email when your registration has been activated by someone on our staff.


Thanks!
<?php echo SITE_NAME?> Staff