<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
Dear <?php echo $pilot->firstname.' '.$pilot->lastname ?>,
Your registration for <?php echo SITE_NAME?> was accepted! Please visit us 
at <a href="<?php echo SITE_URL?>"><?php echo SITE_NAME?></a> to login and complete your registration

Thanks!
<?php echo SITE_NAME?> Staff