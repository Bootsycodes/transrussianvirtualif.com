<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
[ACARS_CONFIG]
ADDRESS=<?php echo actionurl('/fsfk/acars'); ?>

PORT=80

USER=

PASSWORD=

POSITIONREPORT=2

POSITIONREPORT_EX=10

LIVEWATCH=<?php echo actionurl('/fsfk/livewatch'); ?>

LIVEWATCHREFRESH=60