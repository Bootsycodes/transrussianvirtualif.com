<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<p>This email address was not found in our database. If you feel this was an error, please contact an administrator.</p>