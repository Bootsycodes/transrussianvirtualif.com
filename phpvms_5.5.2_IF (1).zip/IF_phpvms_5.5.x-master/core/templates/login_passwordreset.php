<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Password Reset</h3>
<p>Your new password has been sent to your email!</p>