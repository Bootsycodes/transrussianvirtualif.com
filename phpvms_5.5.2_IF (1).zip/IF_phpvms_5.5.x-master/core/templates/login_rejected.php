<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Sorry!</h3>
<p>Your registration was not accepted. Please contact the administrator for additional details.</p>