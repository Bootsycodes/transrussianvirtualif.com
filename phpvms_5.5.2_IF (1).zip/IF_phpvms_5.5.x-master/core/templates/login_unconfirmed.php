<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Unconfirmed</h3>

<p>Sorry! Your registration has not yet been checked by an administrator. Please try again later. You will receive an email when your registration has been accepted</p>