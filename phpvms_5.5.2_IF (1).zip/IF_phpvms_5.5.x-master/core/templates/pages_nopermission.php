<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Not Allowed</h3>
<p>You are not allowed permission to access this page<p>