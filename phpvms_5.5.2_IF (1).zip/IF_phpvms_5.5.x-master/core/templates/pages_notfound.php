<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>You broke it!</h3>
<p>Just kidding. The page you were looking for has run away. Contact the site admin if you think this is an error.<p>