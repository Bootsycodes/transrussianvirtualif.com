<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Thank you!</h3>
<p>Your registration is now complete! You may log-in now</p>