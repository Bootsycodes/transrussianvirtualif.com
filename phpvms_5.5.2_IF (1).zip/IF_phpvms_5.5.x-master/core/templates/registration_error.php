<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<h3>Error Registering</h3>
<p><?php echo $error; ?></p>