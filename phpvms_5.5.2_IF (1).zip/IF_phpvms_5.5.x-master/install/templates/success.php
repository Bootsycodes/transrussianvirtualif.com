<?php
echo '<div id="success">'.$message.'</div>';